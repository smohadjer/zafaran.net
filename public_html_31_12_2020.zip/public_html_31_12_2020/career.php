﻿<?php include('includes/head.php') ?>
	</head>
	<body>
<?php include('includes/sidebar.php') ?>
		<div id="content">
			<div id="career" class="page">
				<h1>Careers</h1>
				<img src="images/career.jpg" width="50%" alt="" />
				<div>
					<p>Zafaran is seeking professionals who have experience in the Oil, Gas and Petrochemical
						industries in the following fields:</p>
					<ul>
						<li>Mechanical Engineer(Rotating and Fixed equipment)</li>
						<li>Electrical Engineer</li>
						<li>Instrument and Control Engineer</li>
						<li>Piping Designer and Analyst</li>
						<li>Process Engineer</li>
						<li>Quality Control</li>
						<li>Mechanical Drafter</li>
					</ul>
					<p>Please send your resume to <a href="mailto:job@zafaran.net">job@zafaran.net</a></p>
				</div>
			</div>
		</div>
	</body>
</html>
